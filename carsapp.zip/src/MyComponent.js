import React, { useState, useEffect } from 'react';
import JSONDATA from './data.json';

function MyComponent() {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  console.log(JSONDATA);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(JSONDATA); // Relative path to the JSON file

        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const jsonData = await response.json();
        console.log(jsonData);
        setData(jsonData);
      } catch (error) {
        setError(error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  return (
    <div>
      {/* Render your JSON data here */}
      <pre>{JSON.stringify(data, null, 2)}</pre>
      {data.map((user, index) => {
        return <div key={index}>
        <p>{user.name}</p>
        <p>{user.age}</p>
        <p>{user.city}</p>
        </div>
      })}
    </div>
  );
}

export default MyComponent;
