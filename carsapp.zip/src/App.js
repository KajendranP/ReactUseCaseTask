import './App.css';
// import CarContainer from './components/car-container/CarContainer';
// import CarList from './components/car-list/CarList';
import Navbar from './components/navbar/Navbar';
import { Route, Routes } from 'react-router-dom';
import Home from './components/home/Home';
import Services from './components/services/Services';
import Gallery from './components/gallery/Gallery';
import Contact from './components/contact/Contact';

function App() {

    return (

    <div className="App">

      <Navbar />
    <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/services" element={<Services />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/contact" element={<Contact />} />
    </Routes>
{/*      
          <Route path="/" component={Home} />
          <Route path="/services" component={Services} />
          <Route path="/gallery" component={Gallery} />
          <Route path="/contact" component={Contact} /> */}
          

      {/* <Switch> */}
      {/* <Route exact path="/" component={CarContainer} />
      <Route path="/cars/:id" component={CarList} /> */}
      {/* <CarContainer />
      <CarList /> */}
      {/* </Switch> */}
      {/* <MyComponent /> */}
      
    </div>
   

  );
}

export default App;
