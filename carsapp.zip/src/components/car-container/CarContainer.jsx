import React, { useState } from "react";
import "../car-container/CarContaier.css";

import data from "../../jsonData/data.json";
import CarList from "../car-list/CarList";

const carFormDetails = {
  model: "Model",
  color: "Color",
  year_of_manufacture: "Year of Manufacture",
  insurance_valid_upto: "Insurance Valid Upto",
  kms: "KMS",
  location: "Location ",
  number_of_owners: "Number of Owners",
  transmission: "Transmission",
  external_fitments: "External Fitments",
  photo: "Photo",
};

const CarContainer = () => {
  const carBrands = data.cars;

  const [selectedCar, setSelectedCar] = useState(null);
  const [selectedValue, setSelectedValue] = useState(null);

  const handleClick = (car) => {
    setSelectedCar(car);
    setSelectedValue(carFormDetails);
  };

  return (
    <>
      <div className="mainContainer">
        <div className="carContainer">
          {carBrands &&
            carBrands.map((carBrand) => (
              <div key={carBrand.id} className="carNameList">
                <div
                  className="carBrandLogo"
                  // onClick={() => handleClick(carBrand.id)}
                  onClick={() => handleClick(carBrand)}
                >
                  <img src={carBrand.logo} alt="Car Logo" />
                  <span className="carModelName">{carBrand.model_name}</span>
                </div>
              </div>
            ))}
          <div className="carNameList">
            <div className="carLogoSize">
              <p className="more">MORE</p>
            </div>
          </div>
        </div>
      </div>
     
        <CarList selectedCar={selectedCar} selectedValue={selectedValue} />
     
    </>
  );
};

export default CarContainer;
