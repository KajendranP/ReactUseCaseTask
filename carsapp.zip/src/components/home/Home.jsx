import React from 'react';
import CarContainer from '../car-container/CarContainer';
// import CarContainer from './components/car-container/CarContainer';
const Home = () => {
  return (
    <div>
      <CarContainer />
    </div>
  )
}

export default Home