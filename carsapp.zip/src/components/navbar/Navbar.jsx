import React from 'react';
import './Navbar.css'; // Import CSS file for styling
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <h4 className='carsAppLogo'>CARS APP</h4>
      </div>
      <ul className="navbar-menu">
        <li className="navbar-menu-item"><Link to="/">Home</Link></li>
        <li className="navbar-menu-item"><Link to="/services">Services</Link></li>
        <li className="navbar-menu-item"><Link to="/gallery">Gallery</Link></li>
        <li className="navbar-menu-item"><Link to="/contact">Contact Us</Link></li>
      </ul>
    </nav>
  );
};

export default Navbar;
