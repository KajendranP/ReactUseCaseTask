import React from 'react';


const Contact = () => {
  return (
    <div className='noRecordsFound'>
      <p>No Records Found</p>
    </div>
  )
}

export default Contact;