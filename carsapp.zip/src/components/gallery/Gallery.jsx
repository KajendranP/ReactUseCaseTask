import React from 'react';


const Gallery = () => {
  return (
    <div className='noRecordsFound'>
      <p>No Records Found</p>
    </div>
  )
}

export default Gallery;