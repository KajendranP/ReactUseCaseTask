import React, { useEffect, useState } from "react";
import "../car-list/CarList.css";

const CarList = ({ selectedCar, selectedValue }) => {
  const [isDisplay, setIsDisplay] = useState(false);; 

  console.log(selectedCar, selectedValue);

  useEffect(() => {
    if (selectedCar && selectedValue !== null) {
      setIsDisplay(true);
    } else {
      setIsDisplay(false);
    }
  }, [selectedCar, selectedValue]);

  return (
    <>
      <div>
        {isDisplay === true ?  (
          <form >
            <div className="formFields">
              <input type="text" value={selectedValue.model} readOnly />
              {selectedCar.model_name}
            </div>
            <div className="formFields">
              <input type="text" value={selectedValue.color} />
              {selectedCar.color}
            </div>
            <div className="formFields">
              <input type="text" value={selectedValue.year_of_manufacture} />
              {selectedCar.year_of_manufacture}
            </div>
            <div className="formFields">
              <input type="text" value={selectedValue.insurance_valid_upto} />
              {selectedCar.insurance_valid_upto}
            </div>
            <div className="formFields">
              <input type="text" value={selectedValue.kms} />
              {selectedCar.kms}
            </div>
            <div className="formFields">
              <input type="text" value={selectedValue.location} />
              {selectedCar.location}
            </div>
            <div className="formFields">
              <input type="text" value={selectedValue.number_of_owners} />
              {selectedCar.number_of_owners}
            </div>
            <div className="formFields">
              <input type="text" value={selectedValue.transmission} />
              {selectedCar.transmission}
            </div>
            <div className="formFields">
              <input type="text" value={selectedValue.external_fitments} />
              {selectedCar.external_fitments}
            </div>
            <div className="formFields">
              <input type="text" value={selectedValue.photo} />
              {selectedValue.photo ? <input type="file" /> : null}
            </div>
          </form>
        ) : null}
      </div>
    </>
  );
};

export default CarList;
